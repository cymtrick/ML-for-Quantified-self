# Vahid Mirjalili 08/07/2015
# Unsupervised Data Clustering Algorithms in Python
# Machine Learning Application

from ._internal import Silhouette

__version__ = '0.1.6'
